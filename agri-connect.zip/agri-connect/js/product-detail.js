document.addEventListener('DOMContentLoaded', function() {
    const productId = localStorage.getItem('selectedProduct');
    const products = JSON.parse(localStorage.getItem('products')) || [];

    if (products[productId]) {
        const product = products[productId];
        const productDetail = document.getElementById('productDetail');

        productDetail.innerHTML = `
            <img src="${product.image}" alt="${product.name}" width="150">
            <h3>${product.name}</h3>
            <p>${product.description}</p>
            <p>Price: ₹${product.price}</p>
            <button onclick="orderProduct(${productId})">Order Now</button>
        `;
    } else {
        productDetail.innerHTML = '<p>Product not found!</p>';
    }
});

function orderProduct(productId) {
    localStorage.setItem('selectedProduct', productId);
    window.location.href = 'order.html';
}
