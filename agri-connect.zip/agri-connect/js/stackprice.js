// Mock data for stock prices
const productData = [
    { name: "Rice", price: 35.5, trend: [] },
    { name: "Carrot", price: 52, trend: [] },
    { name: "Onion Big", price: 60, trend: [] },
    { name: "Potato", price: 37, trend: [] },
    { name: "Tomato", price: 28, trend: [] }
];

// Function to randomly fluctuate prices with sharp ups and downs
function fluctuatePrice(price) {
    const fluctuation = (Math.random() * 5 - 2).toFixed(2); // Random number between -250 and 250
    return Math.max(15, parseFloat(price) + parseFloat(fluctuation)); // Ensure price doesn't fall below a minimum
}

// Update stock ticker
function updateStockTicker() {
    const tickerDiv = document.getElementById('stockTicker');
    tickerDiv.innerHTML = productData.map(product => {
        const latestPrice = product.trend[product.trend.length - 1] || product.price;
        const change = (latestPrice - product.price).toFixed(2);
        const trendClass = change >= 0 ? "product-up" : "product-down";
        return `<span class="${trendClass}">${product.name}: ₹${latestPrice} (${change >= 0 ? '+' : ''}${change}%)</span>`;
    }).join(' | ');
}

// Populate table with stock prices
function populatePriceTable() {
    const tableBody = document.getElementById('productPrices');
    tableBody.innerHTML = productData.map(product => {
        const latestPrice = product.trend[product.trend.length - 1] || product.price;
        const change = (latestPrice - product.price).toFixed(2);
        const trendClass = change >= 0 ? "product-up" : "product-down";
        return `
            <tr>
                <td>${product.name}</td>
                <td>₹${latestPrice}</td>
                <td class="${trendClass}">${change >= 0 ? '+' : ''}${change}%</td>
                <td><span class="${trendClass}">${change >= 0 ? '↑' : '↓'}</span></td>
            </tr>
        `;
    }).join('');
}

// Function to update price trends in the chart
function updatePriceTrends(chart) {
    productData.forEach(product => {
        const newPrice = fluctuatePrice(product.trend[product.trend.length - 1] || product.price);
        product.trend.push(newPrice);

        if (product.trend.length > 10) {
            product.trend.shift(); // Keep trend data at 10 data points max for better visualization
        }

        // Update chart dataset
        chart.data.datasets.forEach((dataset) => {
            if (dataset.label === product.name) {
                dataset.data = product.trend;
            }
        });
    });

    chart.update(); // Redraw chart with new data
}

// Initialize price chart
function initPriceChart() {
    const ctx = document.getElementById('priceChart').getContext('2d');
    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: Array(10).fill(''), // Labels for X-axis (can represent time)
            datasets: productData.map(product => ({
                label: product.name,
                data: [product.price], // Start with the initial price
                borderColor: product.name === 'Rice' ? 'green' : product.name === 'Carrot' ? 'orange' : 'red',
                fill: false,
                tension: 0.1, // Reduced smoothness for sharper line fluctuations
            }))
        },
        options: {
            responsive: true,
            animation: {
                duration: 0 // Disable animation for sharper, faster updates
            },
            scales: {
                x: {
                    title: { display: true, text: 'Time' }
                },
                y: {
                    title: { display: true, text: 'Price (₹)' }
                }
            }
        }
    });

    return chart;
}

// Function to continuously update prices and chart
function startLiveUpdates(chart) {
    setInterval(() => {
        updatePriceTrends(chart);
        populatePriceTable();
        updateStockTicker();
    }, 1000); // Update every 1 second for sharper, live updates
}

// Run on page load
document.addEventListener('DOMContentLoaded', function() {
    updateStockTicker();
    populatePriceTable();

    const priceChart = initPriceChart();
    startLiveUpdates(priceChart); // Start live updates
});
