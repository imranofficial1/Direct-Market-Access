function payWithGoogle() {
    alert('Redirecting to Google Pay...');
    // Add logic for real payment gateway integration
}

function payWithPhonePe() {
    alert('Redirecting to PhonePe...');
    // Add logic for real payment gateway integration
}

function payWithPaytm() {
    alert('Redirecting to Paytm...');
    // Add logic for real payment gateway integration
}
