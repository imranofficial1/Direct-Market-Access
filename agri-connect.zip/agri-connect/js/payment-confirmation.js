document.addEventListener('DOMContentLoaded', function() {
    const productId = localStorage.getItem('selectedProduct');
    const products = JSON.parse(localStorage.getItem('products')) || [];

    if (products[productId]) {
        const product = products[productId];
        const confirmationDetails = document.getElementById('confirmationDetails');

        confirmationDetails.innerHTML = `
            <img src="${product.image}" alt="${product.name}" width="150">
            <h3>${product.name}</h3>
            <p>Price: ₹${product.price}</p>
            <p>Order placed successfully!</p>
        `;
    } else {
        confirmationDetails.innerHTML = '<p>Product not found!</p>';
    }

    // Optionally, clear selected product after confirmation
    localStorage.removeItem('selectedProduct');
});
