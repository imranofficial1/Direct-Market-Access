document.addEventListener('DOMContentLoaded', function() {
    const productId = localStorage.getItem('selectedProduct');
    const products = JSON.parse(localStorage.getItem('products')) || [];

    if (products[productId]) {
        const product = products[productId];
        const orderDetails = document.getElementById('orderDetails');

        orderDetails.innerHTML = `
            <img src="${product.image}" alt="${product.name}" width="150">
            <h3>${product.name}</h3>
            <p>${product.description}</p>
            <p>Price: ₹${product.price}</p>
        `;
    } else {
        orderDetails.innerHTML = '<p>Product not found!</p>';
    }
});

function payWithGoogle() {
    alert('Order successfully placed with Google Pay!');
    orderSuccess();
}

function payWithPhonePe() {
    alert('Order successfully placed with PhonePe!');
    orderSuccess();
}

function payWithPaytm() {
    alert('Order successfully placed with Paytm!');
    orderSuccess();
}

function orderSuccess() {
    // You can implement additional actions here if needed, e.g., saving the order
    // Clear selected product after order completion
    localStorage.removeItem('selectedProduct');
    // Optionally, redirect to a confirmation page
    window.location.href = 'payment-confirmation.html';
}
