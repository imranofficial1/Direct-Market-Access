document.addEventListener('DOMContentLoaded', function() {
    const productList = document.getElementById('productList');

    // Load products from localStorage
    function loadProducts() {
        const products = JSON.parse(localStorage.getItem('products')) || [];
        productList.innerHTML = ''; // Clear the current list

        products.forEach((product, index) => {
            productList.innerHTML += `
                <div class="product-item">
                    <img src="${product.image}" alt="${product.name}" width="100">
                    <h3>${product.name}</h3>
                    <p>${product.description}</p>
                    <p>Price: ₹${product.price}</p>
                    <button onclick="removeProduct(${index})">Remove</button>
                </div>
                <hr>
            `;
        });
    }

    // Add product to localStorage
    document.getElementById('productForm').addEventListener('submit', function(e) {
        e.preventDefault();

        const name = document.getElementById('name').value;
        const description = document.getElementById('description').value;
        const price = document.getElementById('price').value;
        const image = document.getElementById('image').value;

        const product = { name, description, price, image };

        let products = JSON.parse(localStorage.getItem('products')) || [];
        products.push(product);

        localStorage.setItem('products', JSON.stringify(products));
        alert('Product added successfully!');
        this.reset();

        loadProducts(); // Reload the product list
    });

    // Remove product from localStorage
    window.removeProduct = function(index) {
        let products = JSON.parse(localStorage.getItem('products')) || [];
        if (confirm(`Are you sure you want to remove "${products[index].name}"?`)) {
            products.splice(index, 1); // Remove the product at the given index
            localStorage.setItem('products', JSON.stringify(products));
            loadProducts(); // Reload the product list
        }
    };

    // Initial load
    loadProducts();
});
