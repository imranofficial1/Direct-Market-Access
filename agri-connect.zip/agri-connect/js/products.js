document.addEventListener('DOMContentLoaded', function() {
    const products = JSON.parse(localStorage.getItem('products')) || [];
    const productList = document.getElementById('productList');

    if (products.length > 0) {
        products.forEach((product, index) => {
            productList.innerHTML += `
                <div class="product">
                    <img src="${product.image}" alt="${product.name}" width="150">
                    <h3>${product.name}</h3>
                    <p>${product.description}</p>
                    <p>Price: ₹${product.price}</p>
                    <button onclick="viewProduct(${index})">View Details</button>
                </div>
            `;
        });
    } else {
        productList.innerHTML = '<p>No products available</p>';
    }
});

function viewProduct(productId) {
    localStorage.setItem('selectedProduct', productId);
    window.location.href = 'product-detail.html';
}
